Shadow Libraries
=========

In case ePubLibre is down.
