Shadow Libraries
=========

A pirate libraries archive (Spanish Version)
