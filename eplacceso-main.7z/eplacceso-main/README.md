Modos alternativos de acceso a ePubLibre por ShadowLibraries.
